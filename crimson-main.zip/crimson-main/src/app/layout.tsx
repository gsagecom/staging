import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Crimson Industries Corporation | Programme Management",
  description: "Founded as a taskforce of industry experts, Crimson Industries Corporation transcends traditional project management to deliver intelligent infrastructure solutions that shape the future.",
  icons: {
    icon: "/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${inter.className} antialiased`}>
        <Navigation />
        <main className="min-h-screen bg-slate-50">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
